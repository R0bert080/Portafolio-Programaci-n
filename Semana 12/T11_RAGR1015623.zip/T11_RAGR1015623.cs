﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp35
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese el valor del cateto");
            double lcateto = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Ingrese los grados del ángulo opuesto");
            double gopuesto = Convert.ToDouble(Console.ReadLine());

            TrianguloRectangulo objTriangulo = new TrianguloRectangulo(lcateto, gopuesto);

            Console.WriteLine($"El valor del cateto A es de {objTriangulo.ObtenerCatetoA()}");
            Console.WriteLine($"El valor del cateto B es de {objTriangulo.ObtenerCatetoB()}");
            Console.WriteLine($"El valor de la hipotenusa es de {objTriangulo.ObtenerHipotenusa()}");
            Console.WriteLine($"El valor del ángulo opuesto A es de {objTriangulo.ObtenerAnguloOpuestoA()}");
            Console.WriteLine($"El valor del ángulo opuesto B es de {objTriangulo.ObtenerAnguloOpuestoB()}");
            Console.WriteLine($"El valor del área es de {objTriangulo.ObtenerArea()}");

            Console.ReadKey();
        }
    }
}
