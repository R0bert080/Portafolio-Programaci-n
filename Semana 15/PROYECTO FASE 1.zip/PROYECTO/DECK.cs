﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO
{
    internal class DECK1
    {
        private string nombrejugador;
        private string equipo;
        private string nombrecarta;
        private string tipocarta;
        private int puntosvida;
        private int daño;
        private double elixir;
        private double NoCartas;

        public void AddCard1(int puntosVida, int elixir, int daño)
        {
            this.puntosvida += puntosVida;
            this.elixir += elixir;
            this.daño += daño;
            this.NoCartas += 1;
        }
        public void ShowDeckInfo1()
        {
            Console.WriteLine("\nElixir promedio: " + (elixir / NoCartas).ToString("F2"));
            Console.WriteLine("Total Puntos de Vida: " + puntosvida);
            Console.WriteLine("Total Daño: " + daño);
        }
        public int Imprimirpuntosdevida()
        {
            return puntosvida;
        }
        public int Imprimirpuntosdeaño()
        {
            return daño;
        }
    }
    internal class DECK2
    {
        private string nombrejugador;
        private string equipo;
        private string nombrecarta;
        private string tipocarta;
        private int puntosvida;
        private int daño;
        private double elixir;
        private double NoCartas;

        public void AddCard1(int puntosVida, int elixir, int daño)
        {
            this.puntosvida += puntosVida;
            this.elixir += elixir;
            this.daño += daño;
            this.NoCartas += 1;
        }
        public void ShowDeckInfo1()
        {
            Console.WriteLine("\nElixir promedio: " + (elixir / NoCartas).ToString("F2"));
            Console.WriteLine("Total Puntos de Vida: " + puntosvida);
            Console.WriteLine("Total Daño: " + daño);
        }
        public int Imprimirpuntosdevida()
        { 
            return puntosvida; 
        }
        public int Imprimirpuntosdeaño()
        {
            return daño;
        }
    }
    internal class DECK3
    {
        private string nombrejugador;
        private string equipo;
        private string nombrecarta;
        private string tipocarta;
        private int puntosvida;
        private int daño;
        private double elixir;
        private double NoCartas;

        public void AddCard1(int puntosVida, int elixir, int daño)
        {
            this.puntosvida += puntosVida;
            this.elixir += elixir;
            this.daño += daño;
            this.NoCartas += 1;
        }
        public void ShowDeckInfo1()
        {
            Console.WriteLine("\nElixir promedio: " + (elixir / NoCartas).ToString("F2"));
            Console.WriteLine("Total Puntos de Vida: " + puntosvida);
            Console.WriteLine("Total Daño: " + daño);
        }
        public int Imprimirpuntosdevida()
        {
            return puntosvida;
        }
        public int Imprimirpuntosdeaño()
        {
            return daño;
        }
    }
    internal class DECK4
    {
        private string nombrejugador;
        private string equipo;
        private string nombrecarta;
        private string tipocarta;
        private int puntosvida;
        private int daño;
        private double elixir;
        private double NoCartas;

        public void AddCard1(int puntosVida, int elixir, int daño)
        {
            this.puntosvida += puntosVida;
            this.elixir += elixir;
            this.daño += daño;
            this.NoCartas += 1;
        }
        public void ShowDeckInfo1()
        {
            Console.WriteLine("\nElixir promedio: " + (elixir / NoCartas).ToString("F2"));
            Console.WriteLine("Total Puntos de Vida: " + puntosvida);
            Console.WriteLine("Total Daño: " + daño);
        }
        public int Imprimirpuntosdevida()
        {
            return puntosvida;
        }
        public int Imprimirpuntosdeaño()
        {
            return daño;
        }
    }
}
