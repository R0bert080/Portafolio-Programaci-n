﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO
{
    internal class NICKNAME
    {
        public string NickName(string NombreJugador, string EquipoJugador)
        {
            string inicial1j1 = EquipoJugador.Substring(0, 1);
            string inicial2j1 = EquipoJugador.Substring(EquipoJugador.IndexOf(" ") + 1, 1);
            string abreviaturaJugador1 = inicial1j1 + inicial2j1;
            string primer1 = EquipoJugador.Substring(0, EquipoJugador.IndexOf(" ") + 1);
            int numero1j1 = primer1.Length - 1;
            string nickNameJugador1 = $"{abreviaturaJugador1} - {NombreJugador}{numero1j1}0";

            return nickNameJugador1;
        }
    }
}
