﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // En este espacio se solicita el nombre y equipo del primer jugador
            Console.Write("Ingrese el nombre del primer jugador: ");
            string NombreJugador1 = Console.ReadLine();
            Console.Write("Ingrese el nombre de su equipo: ");
            string EquipoJugador1 = Console.ReadLine();

            // En este espacio se solicita el nombre y equipo del segundo jugador
            Console.Write("Ingrese el nombre del segundo jugador: ");
            string NombreJugador2 = Console.ReadLine();
            Console.Write("Ingrese el nombre de su equipo: ");
            string EquipoJugador2 = Console.ReadLine();

            // En esta parte se llaman los nicknames

            NICKNAME NICK = new NICKNAME();
            string NOMBRE1 = NICK.NickName(NombreJugador1,EquipoJugador1);
            string NOMBRE2 = NICK.NickName(NombreJugador2, EquipoJugador2);
            
            // Se muestran ambos nicknames
            Console.WriteLine($"\nNickname del jugador 1: {NOMBRE1}");
            Console.WriteLine($"Nickname del jugador 2: {NOMBRE2}");

            DECK1 Deck1 = new DECK1();
            for (int i = 1; i < 9; i++)
            {
                //Se pide info del primer mazo
                Console.WriteLine($"\nMASO 1");
                Console.WriteLine("Nombre carta " + i);
                string Nombre = Console.ReadLine();
                Console.WriteLine("Elixir carta " + i);
                int Elixir = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("Vida carta " + i);
                int Vida = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("Daño carta " + i);
                int Dano = Convert.ToInt16(Console.ReadLine());
                Deck1.AddCard1(Vida, Elixir, Dano);
            }
            Deck1.ShowDeckInfo1();

            DECK2 Deck2 = new DECK2();
            for (int i = 1; i < 9; i++)
            {
                //Se pide info del primer mazo
                Console.WriteLine($"\nMASO 2");
                Console.WriteLine("Nombre carta " + i);
                string Nombre = Console.ReadLine();
                Console.WriteLine("Elixir carta " + i);
                int Elixir = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("Vida carta " + i);
                int Vida = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("Daño carta " + i);
                int Dano = Convert.ToInt16(Console.ReadLine());
                Deck2.AddCard1(Vida, Elixir, Dano);
            }
            Deck2.ShowDeckInfo1();

            DECK3 Deck3 = new DECK3();
            for (int i = 1; i < 9; i++)
            {
                //Se pide info del primer mazo
                Console.WriteLine($"\nMASO 2");
                Console.WriteLine("Nombre carta " + i);
                string Nombre = Console.ReadLine();
                Console.WriteLine("Elixir carta " + i);
                int Elixir = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("Vida carta " + i);
                int Vida = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("Daño carta " + i);
                int Dano = Convert.ToInt16(Console.ReadLine());
                Deck3.AddCard1(Vida, Elixir, Dano);
            }
            Deck3.ShowDeckInfo1();

            DECK4 Deck4 = new DECK4();
            for (int i = 1; i < 9; i++)
            {
                //Se pide info del primer mazo
                Console.WriteLine($"\nMASO 2");
                Console.WriteLine("Nombre carta " + i);
                string Nombre = Console.ReadLine();
                Console.WriteLine("Elixir carta " + i);
                int Elixir = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("Vida carta " + i);
                int Vida = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("Daño carta " + i);
                int Dano = Convert.ToInt16(Console.ReadLine());
                Deck4.AddCard1(Vida, Elixir, Dano);
            }
            Deck4.ShowDeckInfo1();

            Console.ReadKey();
        }
    }
}
