﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp17
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingresar número positivo entero = ");


            int a;
            while (!int.TryParse(Console.ReadLine(), out a) || a <= 0)
            {
                Console.Write("Número no válido ");
            }

            z(a);
            y(a);
        }

        static void z(int n)
        {
            double c = 0;
            int i = 1;
            while (i <= n)
            {
                c += 1 / i;
                i++;
            }
            Console.WriteLine($" Suma de (1 / 1) + (1 / 2) + (1 / 3) + ... + (1 / {n}) es igual a {c}");
        }

        static void y(int n)
        {
            double d = 0;
            int i = 1;
            while (i <= n)
            {
                d += 1 / Math.Pow(2, i);
                i++;
            }
            Console.WriteLine($" Suma de (1 / 2^1) + (1 / 2^2) + (1 / 2^3) + ... + (1 / 2^{n}) es igual a {d}");

            Console.ReadKey (); 
        }
    }

}