﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp25
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Moto objMotocicleta = new Moto();
            objMotocicleta.crearMotocicleta("2019", 1000, "Italika", 0.12);

            Console.WriteLine(" Modelo: " + objMotocicleta.Modelo + " Precio: " + objMotocicleta.Precio + " Marca: " + objMotocicleta.Marca + " Iva: " + objMotocicleta.Iva);

            Console.WriteLine("Precio sin IVA: " + objMotocicleta.Precio + " Precio con IVA: " + objMotocicleta.Precio * 1.12 + " Monto del IVA: " + 1000*0.12);
            Console.ReadKey();
        }
    }
}
