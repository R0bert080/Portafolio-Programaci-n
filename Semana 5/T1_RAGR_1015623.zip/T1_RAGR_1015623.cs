﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L1__RAGR_1015623
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo programa");
            Console.WriteLine("Nombre");
            String sNombre = Console.ReadLine();
            Console.WriteLine("Edad");
            String sEdad = Console.ReadLine();
            Console.WriteLine("Carrera");
            String sCarrera = Console.ReadLine();
            Console.WriteLine("Cerné");
            String sCarné = Console.ReadLine();

            Console.WriteLine("Soy " + sNombre + " tengo " + sEdad + " años y estudio la carrera de " + sCarrera + " mi número de carné es " + sCarné );

            Console.ReadKey();
        }
    }
}
