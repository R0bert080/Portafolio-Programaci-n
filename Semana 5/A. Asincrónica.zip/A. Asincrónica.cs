﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acrvidad_3_asíncronica__1_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Cantidad de respuestas correctas");
            int sc = int.Parse(Console.ReadLine());
            Console.WriteLine("Cantidad de respuestas incorrectas");
            int si = int.Parse(Console.ReadLine());
            Console.WriteLine("Cantidad de respuestas en blanco");
            int sb = int.Parse(Console.ReadLine());

            int Nota = (sc * 5) - (si * 1);

            Console.WriteLine($"Su nota es de " + Nota);

            Console.ReadKey();
  

        }
    }
}
